========================================
YUJILIFE.ORG — SETUP INSTRUCTIONS
========================================

You now have TWO files to upload to your GoDaddy hosting:

1. admin.php — Your password-protected admin panel
2. index.php — The main website (reads content from admin panel)

SETUP STEPS:

1. Download both files from the outputs folder
2. Log into cPanel on GoDaddy
3. Go to File Manager → public_html
4. Delete your old index.html file
5. Upload admin.php AND index.php to public_html

6. Visit your site:
   - https://yujilife.org — Your live website
   - https://yujilife.org/admin.php — Admin login

FIRST LOGIN:
- Username: admin
- Password: Change@Me123!

SECURITY:
1. IMMEDIATELY change the password in admin.php line 10
   Edit admin.php and replace 'Change@Me123!' with a strong password
2. Re-upload the updated admin.php to GoDaddy

That's it! Now only YOU can edit content from the admin panel.

========================================
