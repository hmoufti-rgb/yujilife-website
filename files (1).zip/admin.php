<?php
// YujiLife Admin Panel
// IMPORTANT: Change the password below to something strong

session_start();

// ─── CONFIG ───
$ADMIN_PASSWORD = 'Change@Me123!'; // CHANGE THIS to a strong password
$ADMIN_USERNAME = 'admin';
$DATA_FILE = 'site_content.json';

// ─── LOGIN LOGIC ───
if ($_POST['action'] === 'login') {
    if ($_POST['username'] === $ADMIN_USERNAME && $_POST['password'] === $ADMIN_PASSWORD) {
        $_SESSION['admin_logged_in'] = true;
        $_SESSION['login_time'] = time();
    } else {
        $login_error = '❌ Invalid username or password';
    }
}

if ($_GET['logout'] === '1') {
    session_destroy();
    header('Location: admin.php');
    exit;
}

// Check if logged in
$is_logged_in = isset($_SESSION['admin_logged_in']) && $_SESSION['admin_logged_in'] === true;

// ─── LOAD CONTENT ───
$content = [];
if (file_exists($DATA_FILE)) {
    $content = json_decode(file_get_contents($DATA_FILE), true);
}

// ─── SAVE CONTENT ───
if ($is_logged_in && $_POST['action'] === 'save') {
    $section = $_POST['section'] ?? '';
    $field = $_POST['field'] ?? '';
    $value = $_POST['value'] ?? '';
    
    $content[$section][$field] = $value;
    file_put_contents($DATA_FILE, json_encode($content, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE), LOCK_EX);
    $save_message = '✅ Content saved successfully!';
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>YujiLife Admin Panel</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
            background: #f5f5f5;
            color: #333;
        }
        .container { max-width: 1000px; margin: 0 auto; padding: 20px; }
        
        .login-box {
            background: white;
            padding: 60px 40px;
            border-radius: 8px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
            max-width: 420px;
            margin: 80px auto;
            text-align: center;
        }
        .login-box h1 {
            font-size: 28px;
            margin-bottom: 24px;
            color: #2A6B3C;
        }
        .form-group {
            margin-bottom: 16px;
            text-align: left;
        }
        .form-group label {
            display: block;
            font-size: 12px;
            text-transform: uppercase;
            letter-spacing: 0.1em;
            color: #666;
            margin-bottom: 6px;
        }
        .form-group input {
            width: 100%;
            padding: 12px;
            border: 1px solid #ddd;
            border-radius: 4px;
            font-size: 14px;
        }
        .form-group input:focus {
            outline: none;
            border-color: #2A6B3C;
            box-shadow: 0 0 0 3px rgba(42, 107, 60, 0.1);
        }
        .btn {
            width: 100%;
            padding: 12px;
            background: #2A6B3C;
            color: white;
            border: none;
            border-radius: 4px;
            font-size: 14px;
            font-weight: 600;
            cursor: pointer;
            text-transform: uppercase;
            letter-spacing: 0.1em;
        }
        .btn:hover { background: #1F5029; }
        .error {
            background: #fee;
            color: #c00;
            padding: 12px;
            border-radius: 4px;
            margin-bottom: 16px;
            font-size: 13px;
        }
        
        /* ADMIN DASHBOARD */
        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 20px;
            background: white;
            border-bottom: 1px solid #eee;
            margin-bottom: 20px;
            border-radius: 4px;
        }
        .header h1 { font-size: 24px; color: #2A6B3C; }
        .header a {
            background: #c00;
            color: white;
            padding: 10px 20px;
            text-decoration: none;
            border-radius: 4px;
            font-size: 13px;
            text-transform: uppercase;
        }
        .header a:hover { background: #900; }
        
        .sections {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
            gap: 16px;
            margin-bottom: 32px;
        }
        .section-card {
            background: white;
            padding: 24px;
            border-radius: 4px;
            box-shadow: 0 1px 3px rgba(0,0,0,0.08);
        }
        .section-card h2 {
            font-size: 16px;
            margin-bottom: 16px;
            color: #2A6B3C;
        }
        .section-card .form-group {
            margin-bottom: 12px;
        }
        .section-card textarea {
            width: 100%;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 4px;
            font-family: 'DM Sans', -apple-system, sans-serif;
            font-size: 13px;
            resize: vertical;
            min-height: 80px;
        }
        .section-card textarea:focus {
            outline: none;
            border-color: #2A6B3C;
        }
        .success {
            background: #efe;
            color: #060;
            padding: 12px;
            border-radius: 4px;
            margin-bottom: 16px;
            font-size: 13px;
        }
        .btn-save {
            background: #2A6B3C;
            width: 100%;
            margin-top: 16px;
        }
        .btn-save:hover { background: #1F5029; }
    </style>
</head>
<body>

<?php if (!$is_logged_in): ?>
    <!-- LOGIN PAGE -->
    <div class="login-box">
        <h1>YujiLife Admin</h1>
        <?php if (isset($login_error)): ?>
            <div class="error"><?= $login_error ?></div>
        <?php endif; ?>
        <form method="POST">
            <div class="form-group">
                <label>Username</label>
                <input type="text" name="username" required autofocus>
            </div>
            <div class="form-group">
                <label>Password</label>
                <input type="password" name="password" required>
            </div>
            <input type="hidden" name="action" value="login">
            <button class="btn">Sign In</button>
        </form>
        <p style="margin-top: 24px; font-size: 12px; color: #999;">
            Default: admin / Change@Me123! (change this immediately)
        </p>
    </div>

<?php else: ?>
    <!-- ADMIN DASHBOARD -->
    <div class="container">
        <div class="header">
            <h1>YujiLife Admin Panel</h1>
            <a href="admin.php?logout=1">Sign Out</a>
        </div>

        <?php if (isset($save_message)): ?>
            <div class="success"><?= $save_message ?></div>
        <?php endif; ?>

        <div class="sections">
            <!-- Hero Section -->
            <div class="section-card">
                <h2>🏠 Hero Section</h2>
                <form method="POST">
                    <div class="form-group">
                        <label>Main Headline</label>
                        <textarea name="value" placeholder="Caring for life, in all its forms."><?= htmlspecialchars($content['hero']['headline'] ?? 'Caring for life, in all its forms.') ?></textarea>
                    </div>
                    <div class="form-group">
                        <label>Subtitle</label>
                        <textarea name="value" placeholder="YujiLife works across four connected causes..."><?= htmlspecialchars($content['hero']['subtitle'] ?? '') ?></textarea>
                    </div>
                    <input type="hidden" name="action" value="save">
                    <input type="hidden" name="section" value="hero">
                    <input type="hidden" name="field" value="headline">
                    <button class="btn-save">Save Changes</button>
                </form>
            </div>

            <!-- Mission -->
            <div class="section-card">
                <h2>📋 Mission Statement</h2>
                <form method="POST">
                    <div class="form-group">
                        <label>Mission Text</label>
                        <textarea name="value" placeholder="We believe a community thrives..."><?= htmlspecialchars($content['mission']['text'] ?? '') ?></textarea>
                    </div>
                    <input type="hidden" name="action" value="save">
                    <input type="hidden" name="section" value="mission">
                    <input type="hidden" name="field" value="text">
                    <button class="btn-save">Save Changes</button>
                </form>
            </div>

            <!-- Contact -->
            <div class="section-card">
                <h2>📧 Contact Email</h2>
                <form method="POST">
                    <div class="form-group">
                        <label>Email Address</label>
                        <textarea name="value" placeholder="info@yujilife.org"><?= htmlspecialchars($content['contact']['email'] ?? 'info@yujilife.org') ?></textarea>
                    </div>
                    <input type="hidden" name="action" value="save">
                    <input type="hidden" name="section" value="contact">
                    <input type="hidden" name="field" value="email">
                    <button class="btn-save">Save Changes</button>
                </form>
            </div>

            <!-- Phone -->
            <div class="section-card">
                <h2>☎️ Contact Phone</h2>
                <form method="POST">
                    <div class="form-group">
                        <label>Phone / WhatsApp</label>
                        <textarea name="value" placeholder="+961 76 603 046"><?= htmlspecialchars($content['contact']['phone'] ?? '+961 76 603 046') ?></textarea>
                    </div>
                    <input type="hidden" name="action" value="save">
                    <input type="hidden" name="section" value="contact">
                    <input type="hidden" name="field" value="phone">
                    <button class="btn-save">Save Changes</button>
                </form>
            </div>

            <!-- Social Links -->
            <div class="section-card">
                <h2>🔗 Social Media</h2>
                <form method="POST">
                    <div class="form-group">
                        <label>Instagram URL</label>
                        <textarea name="value" placeholder="https://instagram.com/yujilife"><?= htmlspecialchars($content['social']['instagram'] ?? '') ?></textarea>
                    </div>
                    <input type="hidden" name="action" value="save">
                    <input type="hidden" name="section" value="social">
                    <input type="hidden" name="field" value="instagram">
                    <button class="btn-save">Save</button>
                </form>
            </div>

            <!-- About -->
            <div class="section-card">
                <h2>ℹ️ About Section</h2>
                <form method="POST">
                    <div class="form-group">
                        <label>About Text</label>
                        <textarea name="value" placeholder="YujiLife is a nonprofit..."><?= htmlspecialchars($content['about']['text'] ?? '') ?></textarea>
                    </div>
                    <input type="hidden" name="action" value="save">
                    <input type="hidden" name="section" value="about">
                    <input type="hidden" name="field" value="text">
                    <button class="btn-save">Save Changes</button>
                </form>
            </div>
        </div>

        <div style="background: #f0f0f0; padding: 20px; border-radius: 4px; margin-top: 32px; font-size: 12px; color: #666;">
            <strong>🔐 Security:</strong> Your content is saved to a JSON file. For maximum security, contact your hosting provider to password-protect this admin folder via .htaccess or similar. Your password is: <code style="background:#fff;padding:2px 6px;"><?= $ADMIN_PASSWORD ?></code>
        </div>
    </div>

<?php endif; ?>

</body>
</html>
