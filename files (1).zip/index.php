<?php
// Load content from admin panel
$DATA_FILE = 'site_content.json';
$content = [
    'hero' => ['headline' => 'Caring for life, in all its forms.', 'subtitle' => 'YujiLife works across four connected causes — protecting the environment, rescuing animals, empowering women, and building an inclusive future for children with special needs.'],
    'mission' => ['text' => 'We believe a community thrives when every living thing within it is cared for — its land, its animals, its women, and its children.'],
    'contact' => ['email' => 'info@yujilife.org', 'phone' => '+961 76 603 046'],
    'social' => ['instagram' => '#', 'facebook' => '#'],
    'about' => ['text' => 'Yujilife is built on a simple conviction: the challenges facing our environment, our animals, and our most vulnerable people are deeply connected — and so are their solutions.']
];

if (file_exists($DATA_FILE)) {
    $loaded = json_decode(file_get_contents($DATA_FILE), true);
    if (is_array($loaded)) {
        $content = array_merge($content, $loaded);
    }
}

// Helper to safely output content
function safe_out($value) {
    return htmlspecialchars($value ?? '', ENT_QUOTES, 'UTF-8');
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>YujiLife Association — Animal Shelter, Damascus</title>
<meta name="description" content="<?= safe_out($content['hero']['subtitle']) ?>">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Cormorant+Garamond:ital,wght@0,300;0,400;0,600;1,300;1,400;1,600&family=DM+Sans:ital,opsz,wght@0,9..40,300;0,9..40,400;0,9..40,500;1,9..40,300&display=swap" rel="stylesheet">
<style>
  *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }

  :root {
    --cream: #F6F1EA;
    --cream-dark: #EDE6D9;
    --ink: #1C1814;
    --ink-light: #3A342E;
    --muted: #7A7068;
    --muted-light: #A09890;
    --accent: #2A6B3C;
    --accent-light: #3E8E55;
    --sage: #1B5E30;
    --gold: #2A6B3C;
    --border: rgba(28,24,20,0.10);
    --border-mid: rgba(28,24,20,0.16);
  }

  html { scroll-behavior: smooth; }

  body {
    font-family: 'DM Sans', sans-serif;
    background: var(--cream);
    color: var(--ink);
    overflow-x: hidden;
  }

  /* ─────────────────────────── NAV ─────────────────────────── */
  nav {
    position: sticky;
    top: 0;
    z-index: 100;
    background: var(--cream);
    border-bottom: 1px solid var(--border);
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 0 60px;
    height: 68px;
  }

  .nav-logo {
    font-family: 'Cormorant Garamond', serif;
    font-size: 22px;
    font-weight: 400;
    letter-spacing: 0.12em;
    text-transform: uppercase;
    text-decoration: none;
    color: var(--ink);
  }

  .nav-links {
    display: flex;
    gap: 36px;
    list-style: none;
  }
  .nav-links a {
    font-size: 11.5px;
    letter-spacing: 0.14em;
    text-transform: uppercase;
    text-decoration: none;
    color: var(--muted);
    transition: color 0.2s;
  }
  .nav-links a:hover { color: var(--ink); }

  .nav-donate {
    font-family: 'DM Sans', sans-serif;
    font-size: 11.5px;
    letter-spacing: 0.12em;
    text-transform: uppercase;
    background: var(--accent);
    color: #fff;
    border: none;
    padding: 10px 24px;
    cursor: pointer;
    text-decoration: none;
    transition: background 0.2s;
  }
  .nav-donate:hover { background: var(--accent-light); }

  /* ─────────────────────────── HERO ─────────────────────────── */
  .hero {
    display: grid;
    grid-template-columns: 1fr 1fr;
    min-height: calc(100vh - 68px);
    max-height: 820px;
  }

  .hero-text {
    display: flex;
    flex-direction: column;
    justify-content: center;
    padding: 80px 60px;
    border-right: 1px solid var(--border);
    position: relative;
  }

  .hero-eyebrow {
    display: flex;
    align-items: center;
    gap: 12px;
    margin-bottom: 36px;
  }
  .hero-eyebrow::before {
    content: '';
    display: block;
    width: 40px;
    height: 1px;
    background: var(--accent);
  }
  .hero-eyebrow span {
    font-size: 10.5px;
    letter-spacing: 0.22em;
    text-transform: uppercase;
    color: var(--accent);
  }

  .hero-h1 {
    font-family: 'Cormorant Garamond', serif;
    font-size: clamp(52px, 5.5vw, 76px);
    font-weight: 300;
    line-height: 1.03;
    letter-spacing: -0.01em;
    margin-bottom: 28px;
  }
  .hero-h1 em {
    font-style: italic;
    color: var(--accent);
  }

  .hero-sub {
    font-size: 15px;
    line-height: 1.75;
    color: var(--muted);
    max-width: 380px;
    margin-bottom: 48px;
  }

  .hero-actions {
    display: flex;
    gap: 14px;
    flex-wrap: wrap;
  }

  .btn-primary {
    background: var(--ink);
    color: var(--cream);
    border: 1px solid var(--ink);
    padding: 14px 32px;
    font-family: 'DM Sans', sans-serif;
    font-size: 12px;
    letter-spacing: 0.12em;
    text-transform: uppercase;
    text-decoration: none;
    cursor: pointer;
    transition: all 0.2s;
    display: inline-block;
  }
  .btn-primary:hover {
    background: var(--accent);
    border-color: var(--accent);
  }

  .hero-placeholder {
    width: 100%;
    height: 100%;
    background: linear-gradient(160deg, #D4C4A8 0%, #B8A07A 40%, #9A8460 100%);
    display: flex;
    align-items: center;
    justify-content: center;
    position: relative;
  }
  .hero-placeholder svg { opacity: 0.18; }
  .hero-placeholder-text {
    position: absolute;
    bottom: 28px;
    left: 28px;
    font-family: 'Cormorant Garamond', serif;
    font-size: 13px;
    font-style: italic;
    color: rgba(255,255,255,0.6);
    letter-spacing: 0.08em;
  }

  .hero-stats {
    position: absolute;
    bottom: 0;
    left: 0;
    right: 0;
    background: rgba(20,16,12,0.78);
    backdrop-filter: blur(8px);
    display: flex;
    padding: 22px 28px;
    gap: 0;
  }
  .hero-stat {
    flex: 1;
    padding: 0 20px;
    border-right: 1px solid rgba(255,255,255,0.12);
  }
  .hero-stat:first-child { padding-left: 0; }
  .hero-stat:last-child { border-right: none; }
  .hero-stat-n {
    font-family: 'Cormorant Garamond', serif;
    font-size: 32px;
    font-weight: 300;
    color: #fff;
    line-height: 1;
    margin-bottom: 4px;
  }
  .hero-stat-l {
    font-size: 10px;
    letter-spacing: 0.14em;
    text-transform: uppercase;
    color: rgba(255,255,255,0.48);
  }

  /* ─────────────────────────── MARQUEE ─────────────────────────── */
  .marquee {
    background: var(--ink);
    padding: 12px 0;
    overflow: hidden;
    white-space: nowrap;
  }
  .marquee-track {
    display: inline-block;
    animation: roll 28s linear infinite;
  }
  .marquee-track span {
    font-size: 10.5px;
    letter-spacing: 0.2em;
    text-transform: uppercase;
    color: rgba(255,255,255,0.38);
    margin: 0 44px;
  }
  .marquee-track span.dot { color: var(--accent); margin: 0 16px; font-size: 14px; }
  @keyframes roll {
    from { transform: translateX(0); }
    to { transform: translateX(-50%); }
  }

  /* ─────────────────────────── SECTION LAYOUT ─────────────────────────── */
  .section-row {
    display: grid;
    grid-template-columns: 220px 1fr;
    border-bottom: 1px solid var(--border);
  }

  .section-sidebar {
    padding: 64px 40px 64px 60px;
    border-right: 1px solid var(--border);
    display: flex;
    flex-direction: column;
    gap: 10px;
  }
  .section-num {
    font-family: 'Cormorant Garamond', serif;
    font-size: 80px;
    font-weight: 300;
    color: rgba(28,24,20,0.05);
    line-height: 1;
    margin-top: auto;
  }
  .section-tag {
    font-size: 10px;
    letter-spacing: 0.22em;
    text-transform: uppercase;
    color: var(--muted-light);
  }

  .section-body {
    padding: 64px 60px;
  }

  /* ─────────────────────────── MISSION ─────────────────────────── */
  .mission-headline {
    font-family: 'Cormorant Garamond', serif;
    font-size: clamp(36px, 3vw, 50px);
    font-weight: 300;
    line-height: 1.18;
    margin-bottom: 24px;
  }
  .mission-headline em { font-style: italic; color: var(--sage); }

  .mission-body {
    font-size: 15px;
    line-height: 1.82;
    color: var(--muted);
    max-width: 560px;
    margin-bottom: 48px;
  }

  /* ─────────────────────────── FOOTER ─────────────────────────── */
  footer {
    background: var(--ink);
    padding: 60px 60px 32px;
  }

  .footer-top {
    display: grid;
    grid-template-columns: 1.6fr 1fr 1fr 1fr;
    gap: 60px;
    padding-bottom: 48px;
    border-bottom: 1px solid rgba(255,255,255,0.08);
  }

  .footer-brand p {
    font-size: 13px;
    line-height: 1.7;
    color: rgba(255,255,255,0.45);
    max-width: 240px;
  }

  .footer-col-title {
    font-size: 10px;
    letter-spacing: 0.22em;
    text-transform: uppercase;
    color: rgba(255,255,255,0.35);
    margin-bottom: 20px;
  }

  .contact-link {
    font-size: 13.5px;
    color: rgba(255,255,255,0.55);
    text-decoration: none;
    transition: color 0.2s;
  }
  .contact-link:hover { color: rgba(255,255,255,0.9); }

  .footer-bottom {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding-top: 28px;
  }
  .footer-copy {
    font-size: 11.5px;
    color: rgba(255,255,255,0.28);
    letter-spacing: 0.06em;
  }

  .admin-link {
    position: fixed;
    bottom: 20px;
    right: 20px;
    background: var(--accent);
    color: white;
    padding: 8px 14px;
    text-decoration: none;
    border-radius: 4px;
    font-size: 11px;
    letter-spacing: 0.1em;
    text-transform: uppercase;
    opacity: 0.3;
    transition: opacity 0.2s;
  }
  .admin-link:hover { opacity: 1; }

  @media (max-width: 900px) {
    nav { padding: 0 24px; }
    .hero { grid-template-columns: 1fr; max-height: none; }
    .hero-text { padding: 52px 24px 40px; border-right: none; border-bottom: 1px solid var(--border); }
    .section-row { grid-template-columns: 1fr; }
    .section-sidebar { padding: 32px 24px 0; border-right: none; border-bottom: none; }
    .section-num { display: none; }
    .section-body { padding: 24px 24px 48px; }
    footer { padding: 48px 24px 24px; }
    .footer-top { grid-template-columns: 1fr 1fr; gap: 32px; }
    .footer-brand { grid-column: 1 / -1; }
  }
</style>
</head>
<body>

<!-- NAV -->
<nav>
  <a href="#" class="nav-logo">YujiLife</a>
  <ul class="nav-links">
    <li><a href="#about">About</a></li>
    <li><a href="#programs">Programs</a></li>
    <li><a href="#involve">Get Involved</a></li>
    <li><a href="#contact">Contact</a></li>
  </ul>
  <a href="#contact" class="nav-donate">Donate</a>
</nav>

<!-- HERO -->
<section class="hero">
  <div class="hero-text">
    <div class="hero-eyebrow">
      <span>Damascus, Syria — Est. 2020</span>
    </div>
    <h1 class="hero-h1"><?= safe_out($content['hero']['headline']) ?></h1>
    <p class="hero-sub"><?= safe_out($content['hero']['subtitle']) ?></p>
    <div class="hero-actions">
      <a href="#involve" class="btn-primary">Get Involved</a>
    </div>
  </div>
  <div class="hero-placeholder">
    <svg width="120" height="120" viewBox="0 0 120 120" fill="none" xmlns="http://www.w3.org/2000/svg">
      <ellipse cx="60" cy="84" rx="32" ry="22" fill="white"/>
      <circle cx="32" cy="46" r="13" fill="white"/>
      <circle cx="88" cy="46" r="13" fill="white"/>
      <circle cx="60" cy="56" r="26" fill="white"/>
      <ellipse cx="51" cy="52" rx="5" ry="6.5" fill="#9A8460"/>
      <ellipse cx="69" cy="52" rx="5" ry="6.5" fill="#9A8460"/>
      <ellipse cx="60" cy="63" rx="6" ry="4.5" fill="#9A8460"/>
    </svg>
    <p class="hero-placeholder-text">Replace with your hero photo</p>
    <div class="hero-stats">
      <div class="hero-stat">
        <div class="hero-stat-n">240+</div>
        <div class="hero-stat-l">Animals Rescued</div>
      </div>
      <div class="hero-stat">
        <div class="hero-stat-n">180+</div>
        <div class="hero-stat-l">Adopted</div>
      </div>
      <div class="hero-stat">
        <div class="hero-stat-n">12</div>
        <div class="hero-stat-l">Volunteers</div>
      </div>
    </div>
  </div>
</section>

<!-- MARQUEE -->
<div class="marquee" aria-hidden="true">
  <div class="marquee-track">
    <span class="dot">✦</span><span>Rescue</span>
    <span class="dot">✦</span><span>Rehabilitate</span>
    <span class="dot">✦</span><span>Rehome</span>
    <span class="dot">✦</span><span>Damascus, Syria</span>
    <span class="dot">✦</span><span>Nonprofit</span>
    <span class="dot">✦</span><span>Adopt Don't Shop</span>
    <span class="dot">✦</span><span>Animal Welfare</span>
    <span class="dot">✦</span><span>Rescue</span>
    <span class="dot">✦</span><span>Rehabilitate</span>
    <span class="dot">✦</span><span>Rehome</span>
    <span class="dot">✦</span><span>Damascus, Syria</span>
    <span class="dot">✦</span><span>Nonprofit</span>
    <span class="dot">✦</span><span>Adopt Don't Shop</span>
    <span class="dot">✦</span><span>Animal Welfare</span>
  </div>
</div>

<!-- ABOUT / MISSION -->
<section id="about" class="section-row">
  <div class="section-sidebar">
    <p class="section-tag">01 — Mission</p>
    <div class="section-num">01</div>
  </div>
  <div class="section-body">
    <h2 class="mission-headline"><?= safe_out($content['mission']['text']) ?></h2>
    <p class="mission-body"><?= safe_out($content['about']['text']) ?></p>
  </div>
</section>

<!-- FOOTER -->
<footer>
  <div class="footer-top">
    <div class="footer-brand">
      <p><strong>YujiLife Association</strong></p>
      <p><?= safe_out($content['mission']['text']) ?></p>
    </div>
    <div>
      <p class="footer-col-title">Navigation</p>
      <p><a href="#about" class="contact-link">About</a></p>
      <p><a href="#programs" class="contact-link">Programs</a></p>
      <p><a href="#involve" class="contact-link">Get Involved</a></p>
    </div>
    <div>
      <p class="footer-col-title">Support</p>
      <p><a href="#contact" class="contact-link">Donate</a></p>
      <p><a href="#contact" class="contact-link">Volunteer</a></p>
      <p><a href="#contact" class="contact-link">Partner</a></p>
    </div>
    <div>
      <p class="footer-col-title">Contact</p>
      <p><a href="mailto:<?= safe_out($content['contact']['email']) ?>" class="contact-link"><?= safe_out($content['contact']['email']) ?></a></p>
      <p><a href="tel:<?= str_replace(' ', '', safe_out($content['contact']['phone'])) ?>" class="contact-link"><?= safe_out($content['contact']['phone']) ?></a></p>
    </div>
  </div>
  <div class="footer-bottom">
    <p class="footer-copy">© 2026 YujiLife Association — All rights reserved</p>
  </div>
</footer>

<!-- ADMIN LINK (hidden, hover bottom-right to find) -->
<a href="admin.php" class="admin-link" title="Admin Panel">⚙️ Admin</a>

<script>
  document.querySelectorAll('a[href^="#"]').forEach(link => {
    link.addEventListener('click', e => {
      const target = document.querySelector(link.getAttribute('href'));
      if (target) {
        e.preventDefault();
        target.scrollIntoView({ behavior: 'smooth' });
      }
    });
  });
</script>

</body>
</html>
